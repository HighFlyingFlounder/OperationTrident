﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class getKey : Subscene
{
    //子场景是否初始化：动画，敌人生成，whatever
    protected bool mInitialized = false;

    public string nextState = null;

    public bool confirm = false;

    //@override
    public override void onSubsceneInit()
    {
    }

    ///@override
    public override bool isTransitionTriggered()
    {
        if (confirm)
        {
            confirm = false;
            return true;
        }
        else
            return false;
    }

    ///@override
    public override string GetNextSubscene()
    {
        return nextState;
    }

    void Update()
    {

    }

    ///@override
    public override void onSubsceneDestory()
    {
    }

    public void trigger()
    {
        confirm = true;
    }
}
