﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class testTrigger : MonoBehaviour {
    public string state;

    public SubsceneController controller;

    public void OnTriggerEnter(Collider other)
    {
        Component obj = controller.GetComponent(state);
        if (other.tag == "player")
        {
            Debug.Log("?");
            if(obj != null)
                (obj as openTheDoor).trigger();
        }
    }
}
