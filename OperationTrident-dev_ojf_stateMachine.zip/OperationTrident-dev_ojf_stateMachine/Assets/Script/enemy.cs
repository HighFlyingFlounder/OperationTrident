﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemy : MonoBehaviour {
    int mount = 0;

    void Update()
    {
        if (mount == 0)
        {
            transform.Rotate(0.0f, Random.Range(-110, 110), 0.0f);
            transform.Translate(0.0f, 0.0f, 0.3f);

            mount = 20;
        }
        else
            mount--;
        //Debug.Log(this.tag);
    }

    void OnTriggerEnter(Collider other)
    {
        //Debug.Log(other.tag);
    }
}
