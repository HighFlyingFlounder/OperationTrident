﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bullet : MonoBehaviour {
    public float speed = 5.0f;

    // Update is called once per frame
    void Update()
    {
        //Debug.Log(this.tag);
        transform.Translate(0.0f, 0.0f, speed * Time.deltaTime);
    }

    void OnTriggerEnter(Collider other) {
        //Debug.Log(other);
        if (other.tag == "enemy")
        {
            Destroy(other.gameObject);
            Destroy(this.gameObject);
        }   
    }
}
