﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class driver : MonoBehaviour {
    public SubsceneController controller;
    public void Start()
    {
        controller.addSubscene("消灭门外敌人", "killAllBoxes");
        controller.addSubscene("跑到门附近", "openTheDoor");
        controller.addSubscene("获取钥匙","getKey");
        controller.setInitialSubState("消灭门外敌人", "killAllBoxes");
       
    }
}
