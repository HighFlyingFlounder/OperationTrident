﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class openTheDoor : Subscene {

    //子场景是否初始化：动画，敌人生成，whatever
    protected bool mInitialized = false;

    //子场景是否可以跳转到下一个场景
    protected bool mStateCanChage = false;

    public GameObject enemyPrefab;

    public GameObject door;

    protected ArrayList enemyList = new ArrayList();

    public string nextState = null;

    public bool confirm = false;

    //@override
    public override void onSubsceneInit()
    {
        if (!mInitialized)
        {
            for (int i = 0; i < 3; ++i)
            {
                GameObject enemy = Instantiate(enemyPrefab) as GameObject;
                enemy.transform.position = new Vector3(-5.0f + i * 2, 2.0f, -3.0f);
                enemyList.Add(enemy);
            }
            mInitialized = true;
        }
    }

    ///@override
    public override bool isTransitionTriggered()
    {
        if (confirm)
        {
            confirm = false;
            return true;
        }
        else
            return false;
    }

    ///@override
    public override string GetNextSubscene()
    {
        return nextState;
    }

    void Update()
    {
    }

    ///@override
    public override void onSubsceneDestory()
    {
        foreach (GameObject obj in enemyList)
        {
            Destroy(obj);
        }
        mInitialized = false;
    }


    public void trigger()
    {
        Destroy(door);
        confirm = true;
    }
}
