﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class testTrigger2 : MonoBehaviour
{
    public string state;

    public SubsceneController controller;

    public void OnTriggerExit(Collider other)
    {
        Component obj = controller.GetComponent(state); 
        if(obj != null)
            (obj as getKey).trigger();
    }
}